
document.getElementById('root').innerText = 'Salut de la React frontend!';
